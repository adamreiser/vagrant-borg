/* guid.h */

#ifndef GUID_H
#define GUID_H

typedef unsigned int guid;

extern int guid_eq(guid a, guid b);

#endif /* !GUID_H */
