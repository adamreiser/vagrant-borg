#include "buildid.h"

const char *buildid = VERSION_NAME " " VERSION_STRING;
const char *buildver = VERSION_STRING;
